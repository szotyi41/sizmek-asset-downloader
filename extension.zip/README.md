# Fresh Chrome Extension boilerplate (Manifest V3)

## Purpose

This extension can be used as a boilerplate for creating new extensions for Chrome based browsers, like Google Chrome.

## What it does

When installed it will write something to DevTools console (F12) at the three most common events: before page load, after page load and when the user clicks the extension button on browser top bar.
