// this code will be executed after page load
(function() {
  console.log('after.js executed');
})();
